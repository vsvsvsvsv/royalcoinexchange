import React from 'react';
export default function CoinStore() { return <div>Royal Coin Exchange</div>; }